# Study Helper workflow

## Content workflow
1. Add a subject.
2. Add chapters to that subject.
3. Add subtopics to each chapter.
4. Create flashcards and quiz questions from what you studied.
5. Use the study workflow checklist for preview → question → learn → recall → test → revisit.

## Suggested review rhythm
Use tomorrow, a few days later, and next week as a starting reminder pattern. Adjust based on difficulty and performance. This is a lightweight suggestion, not a claim that one interval schedule works for everyone.

## GitHub-only publishing
Upload the extracted project files to the root of your repository. In Settings → Pages, select GitHub Actions. The included workflow deploys the root directory on every push to `main`.
