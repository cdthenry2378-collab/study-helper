# Study Helper — browser-first starter

A responsive, installable Progressive Web App (PWA) designed for Android phones and desktop/PC browsers. No local software is needed to edit the project: use GitHub's website.

## What's included
- Custom app icon assets (1024, 512, 192, Apple touch icon, favicon)
- Responsive desktop sidebar and mobile bottom navigation
- Subjects → chapters → subtopics hierarchy
- Create flashcards and mark them for practice
- Create multiple-choice quiz questions and check results
- Study workflow checklist based on preview, question, learn, recall, test, revisit
- Local device storage via `localStorage`
- Basic service worker caching for repeat visits
- GitHub Actions workflow for automatic GitHub Pages deployment

## Quick start with GitHub only
1. Create a new repository named `study-helper`.
2. Upload the contents of this ZIP to the repository root (not the ZIP itself). On GitHub, use **Add file → Upload files**.
3. Commit the files to the `main` branch.
4. Open **Settings → Pages** and set **Build and deployment → Source** to **GitHub Actions**.
5. Open the **Actions** tab and wait for `Deploy Study Helper to GitHub Pages` to finish.
6. Open the published Pages URL shown in the workflow run.

The app uses relative asset paths and is intended to work when hosted at a GitHub Pages project URL.

## Android installation
Open the published site in Chrome on Android. Use the browser menu and choose **Install app** or **Add to Home screen** when available. This is a PWA, not a Play Store APK.

## PC use
Open the published site in Chrome, Edge, Firefox, or another modern browser. It adapts to wide and narrow screens. Chromium browsers may offer an install icon for the PWA.

## Important limitations
- This starter stores data locally in the browser on each device. It does not sync between PC and phone and clearing browser data can erase the library.
- There is no account system, cloud database, AI content generation, or cross-device synchronization yet.
- “Unlimited” means there is no intentional app-imposed item cap; device storage and browser quotas still apply.
- The workflow uses spaced-review guidance as a checklist; it is not yet a fully adaptive scheduling engine.
- GitHub Pages serves the web app. A native Android APK/iOS app would require a separate build and publishing step.
- Review all GitHub Actions dependency versions and security settings periodically before production use.
